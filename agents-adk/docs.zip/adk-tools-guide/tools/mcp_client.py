"""
MCP integration sketch:
1) Connect ADK agent to an MCP server (e.g., filesystem).
2) Use exposed MCP tools as if they were ADK tools.
3) Or expose your ADK tools via an MCP server.
"""
# See official docs for concrete client/server wiring.
